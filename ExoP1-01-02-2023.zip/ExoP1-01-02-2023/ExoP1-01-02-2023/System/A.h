﻿#pragma once
#include "B.h"

class A
{
private:
    B* bahDommage = new B();
    static inline std::string str = "";
    int* tab = new int[400];
    float sabug = 0.0f;
    ~A();
public:
    void Test();
    void Hello();
};
