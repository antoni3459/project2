﻿#pragma once
#include "A.h"

class B
{
public:
    void Start();
};
