﻿#include "A.h"

A::~A()
{
    
}
void A::Hello()
{
    float _t = sebug;
}
